You may use this library under the terms of either the MIT License or the GNU Lesser General Public License (LGPL) Version 3

The MIT License is recommended for most projects. It is simple and easy to understand and it places almost no restrictions on what you can do with the library.

If the LGPL suits your project better you are also free to use the library under that license.

You don’t have to do anything special to choose one license or the other and you don’t have to notify anyone which license you are using. You are free to use this library in commercial projects as long as the copyright header is left intact.

Licenses

[MIT License](MIT_LICENSE.txt) ([More Information](http://en.wikipedia.org/wiki/MIT_License))

[LGPL](LGPL.txt) ([More Information](http://en.wikipedia.org/wiki/GNU_Lesser_General_Public_License))

Since the LGPL extends the [GPL](GPL.txt), that license has been also included in this distribution.