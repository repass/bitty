#!/bin/sh
export QUICK2WIRE_API_HOME=/home/repass/src/htu21d/quick2wire-python-api
export PYTHONPATH=$PYTHONPATH:$QUICK2WIRE_API_HOME


